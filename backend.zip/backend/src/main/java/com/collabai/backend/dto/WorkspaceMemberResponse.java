package com.collabai.backend.dto;

public class WorkspaceMemberResponse {

    private Long id;
    private String fullName;
    private String email;
    private String role;

    public WorkspaceMemberResponse() {
    }

    public WorkspaceMemberResponse(Long id, String fullName,
                                   String email, String role) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.role = role;
    }

    public Long getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
